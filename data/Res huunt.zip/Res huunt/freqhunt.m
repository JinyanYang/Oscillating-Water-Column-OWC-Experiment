clc  % Clear the command window
close all  % Close all figure windows
clear  % Clear all variables from the workspace

% Constants for the experiment
rhow = 1000;  % Density of water (kg/m^3)
rhoa = 1.227;  % Density of air (kg/m^3)
grav = 9.81;  % Gravitational acceleration (m/s^2)

% Orifice parameters
odia = 30E-3;  % Orifice diameter (m)
A = pi * odia^2 / 4;  % Orifice area (m^2)

% Wave parameters
Wamp = 30E-3;  % Wave amplitude (m)
freq = [0.4:0.1:1.3];  % Wave frequency range (Hz)

% Experimental constants
Cd = 0.62;  % Discharge coefficient
Fs = 128;  % Sampling frequency (Hz)


path = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\stillwater.tom';
path1 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp04hz30mmori.tom';
path2 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp05hz30mmori.tom';
path3 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp06hz30mmori.tom';
path4 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp07hz30mmori.tom';
path5 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp08hz30mmori.tom';
path6 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp09hz30mmori.tom';
path7 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp10hz30mmori.tom';
path8 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp11hz30mmori.tom';
path9 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp12hz30mmori.tom';
path10 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\Res huunt\\30mmamp13hz30mmori.tom';

% Import and calibrate data for each test
% The `zeroer` function is used to calibrate the test data by removing offsets from the stillwater baseline data.
data1 = zeroer(path, path1); % Calibrate test data from path1
data2 = zeroer(path, path2); % Calibrate test data from path2
data3 = zeroer(path, path3); % Calibrate test data from path3
data4 = zeroer(path, path4); % Calibrate test data from path4
data5 = zeroer(path, path5); % Calibrate test data from path5
data6 = zeroer(path, path6); % Calibrate test data from path6
data7 = zeroer(path, path7); % Calibrate test data from path7
data8 = zeroer(path, path8); % Calibrate test data from path8
data9 = zeroer(path, path9); % Calibrate test data from path9
data10 = zeroer(path, path10); % Calibrate test data from path10

% Extract time vectors from each dataset
% Each dataset contains time as the first column. This extracts the time series for each test.
time1 = data1(:,1); % Time vector for test 1
time2 = data2(:,1); % Time vector for test 2
time3 = data3(:,1); % Time vector for test 3
time4 = data4(:,1); % Time vector for test 4
time5 = data5(:,1); % Time vector for test 5
time6 = data6(:,1); % Time vector for test 6
time7 = data7(:,1); % Time vector for test 7
time8 = data8(:,1); % Time vector for test 8
time9 = data9(:,1); % Time vector for test 9
time10 = data10(:,1); % Time vector for test 10

% Calculate pressure for each test (Pa)
% The pressure is calculated from the fourth column of each dataset, which contains pressure data in mmH?O.
% The conversion from mmH?O to Pascal is performed using water density and gravitational acceleration.
press1 = rhow * grav * data1(:,4) / 1000; % Pressure for test 1
press2 = rhow * grav * data2(:,4) / 1000; % Pressure for test 2
press3 = rhow * grav * data3(:,4) / 1000; % Pressure for test 3
press4 = rhow * grav * data4(:,4) / 1000; % Pressure for test 4
press5 = rhow * grav * data5(:,4) / 1000; % Pressure for test 5
press6 = rhow * grav * data6(:,4) / 1000; % Pressure for test 6
press7 = rhow * grav * data7(:,4) / 1000; % Pressure for test 7
press8 = rhow * grav * data8(:,4) / 1000; % Pressure for test 8
press9 = rhow * grav * data9(:,4) / 1000; % Pressure for test 9
press10 = rhow * grav * data10(:,4) / 1000; % Pressure for test 10

% Calculate mass flow rate for each test (kg/s)
% The mass flow rate is calculated using the orifice equation: Cd*A*sqrt(2*rhoa*abs(press)).
% The `sign` function ensures the flow direction is correctly assigned.
mdot1 = Cd * A * sqrt(2 * rhoa * abs(press1)) .* sign(press1); % Mass flow rate for test 1
mdot2 = Cd * A * sqrt(2 * rhoa * abs(press2)) .* sign(press2); % Mass flow rate for test 2
mdot3 = Cd * A * sqrt(2 * rhoa * abs(press3)) .* sign(press3); % Mass flow rate for test 3
mdot4 = Cd * A * sqrt(2 * rhoa * abs(press4)) .* sign(press4); % Mass flow rate for test 4
mdot5 = Cd * A * sqrt(2 * rhoa * abs(press5)) .* sign(press5); % Mass flow rate for test 5
mdot6 = Cd * A * sqrt(2 * rhoa * abs(press6)) .* sign(press6); % Mass flow rate for test 6
mdot7 = Cd * A * sqrt(2 * rhoa * abs(press7)) .* sign(press7); % Mass flow rate for test 7
mdot8 = Cd * A * sqrt(2 * rhoa * abs(press8)) .* sign(press8); % Mass flow rate for test 8
mdot9 = Cd * A * sqrt(2 * rhoa * abs(press9)) .* sign(press9); % Mass flow rate for test 9
mdot10 = Cd * A * sqrt(2 * rhoa * abs(press10)) .* sign(press10); % Mass flow rate for test 10

% Calculate volumetric flow rate for each test (m^3/s)
% Volumetric flow rate is derived by dividing the mass flow rate by air density.
Q1 = mdot1 / rhoa; % Volumetric flow rate for test 1
Q2 = mdot2 / rhoa; % Volumetric flow rate for test 2
Q3 = mdot3 / rhoa; % Volumetric flow rate for test 3
Q4 = mdot4 / rhoa; % Volumetric flow rate for test 4
Q5 = mdot5 / rhoa; % Volumetric flow rate for test 5
Q6 = mdot6 / rhoa; % Volumetric flow rate for test 6
Q7 = mdot7 / rhoa; % Volumetric flow rate for test 7
Q8 = mdot8 / rhoa; % Volumetric flow rate for test 8
Q9 = mdot9 / rhoa; % Volumetric flow rate for test 9
Q10 = mdot10 / rhoa; % Volumetric flow rate for test 10

% Calculate absorbed power for each test (W)
% Absorbed power is computed as the product of volumetric flow rate and pressure, taking the absolute value.
Pow1 = abs(Q1 .* press1); % Absorbed power for test 1
Pow2 = abs(Q2 .* press2); % Absorbed power for test 2
Pow3 = abs(Q3 .* press3); % Absorbed power for test 3
Pow4 = abs(Q4 .* press4); % Absorbed power for test 4
Pow5 = abs(Q5 .* press5); % Absorbed power for test 5
Pow6 = abs(Q6 .* press6); % Absorbed power for test 6
Pow7 = abs(Q7 .* press7); % Absorbed power for test 7
Pow8 = abs(Q8 .* press8); % Absorbed power for test 8
Pow9 = abs(Q9 .* press9); % Absorbed power for test 9
Pow10 = abs(Q10 .* press10); % Absorbed power for test 10

% Extract water column displacement for each test (m)
% Water column displacement data is extracted from the third column of each dataset and converted from mm to m.
OWCWP1 = data1(:,3) / 1000; % Water column displacement for test 1
OWCWP2 = data2(:,3) / 1000; % Water column displacement for test 2
OWCWP3 = data3(:,3) / 1000; % Water column displacement for test 3
OWCWP4 = data4(:,3) / 1000; % Water column displacement for test 4
OWCWP5 = data5(:,3) / 1000; % Water column displacement for test 5
OWCWP6 = data6(:,3) / 1000; % Water column displacement for test 6
OWCWP7 = data7(:,3) / 1000; % Water column displacement for test 7
OWCWP8 = data8(:,3) / 1000; % Water column displacement for test 8
OWCWP9 = data9(:,3) / 1000; % Water column displacement for test 9
OWCWP10 = data10(:,3) / 1000; % Water column displacement for test 10

% Calculate peak-to-peak amplitude for each test (m)
% Peak-to-peak amplitude is calculated as the difference between the maximum and minimum values, divided by 2.
AMP1MM = (max(OWCWP1) - min(OWCWP1)) / 2; % Peak-to-peak amplitude for test 1
AMP2MM = (max(OWCWP2) - min(OWCWP2)) / 2; % Peak-to-peak amplitude for test 2
AMP3MM = (max(OWCWP3) - min(OWCWP3)) / 2; % Peak-to-peak amplitude for test 3
AMP4MM = (max(OWCWP4) - min(OWCWP4)) / 2; % Peak-to-peak amplitude for test 4
AMP5MM = (max(OWCWP5) - min(OWCWP5)) / 2; % Peak-to-peak amplitude for test 5
AMP6MM = (max(OWCWP6) - min(OWCWP6)) / 2; % Peak-to-peak amplitude for test 6
AMP7MM = (max(OWCWP7) - min(OWCWP7)) / 2; % Peak-to-peak amplitude for test 7
AMP8MM = (max(OWCWP8) - min(OWCWP8)) / 2; % Peak-to-peak amplitude for test 8
AMP9MM = (max(OWCWP9) - min(OWCWP9)) / 2; % Peak-to-peak amplitude for test 9
AMP10MM = (max(OWCWP10) - min(OWCWP10)) / 2; % Peak-to-peak amplitude for test 10

% Calculate RMS amplitude for each test (m)
% RMS amplitude is computed using the root mean square of the displacement values, scaled by sqrt(2).
AMP1RMS = sqrt(2) * rms(OWCWP1); % RMS amplitude for test 1
AMP2RMS = sqrt(2) * rms(OWCWP2); % RMS amplitude for test 2
AMP3RMS = sqrt(2) * rms(OWCWP3); % RMS amplitude for test 3
AMP4RMS = sqrt(2) * rms(OWCWP4); % RMS amplitude for test 4
AMP5RMS = sqrt(2) * rms(OWCWP5); % RMS amplitude for test 5
AMP6RMS = sqrt(2) * rms(OWCWP6); % RMS amplitude for test 6
AMP7RMS = sqrt(2) * rms(OWCWP7); % RMS amplitude for test 7
AMP8RMS = sqrt(2) * rms(OWCWP8); % RMS amplitude for test 8
AMP9RMS = sqrt(2) * rms(OWCWP9); % RMS amplitude for test 9
AMP10RMS = sqrt(2) * rms(OWCWP10); % RMS amplitude for test 10


% Display calculated amplitudes
% Display both peak-to-peak and RMS amplitudes for all tests for validation and comparison.
disp('Amp of OWC using max/min is'); disp(AMP1MM); % Test 1 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP1RMS); % Test 1 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP2MM); % Test 2 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP2RMS); % Test 2 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP3MM); % Test 3 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP3RMS); % Test 3 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP4MM); % Test 4 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP4RMS); % Test 4 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP5MM); % Test 5 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP5RMS); % Test 5 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP6MM); % Test 6 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP6RMS); % Test 6 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP7MM); % Test 7 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP7RMS); % Test 7 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP8MM); % Test 7 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP8RMS); % Test 7 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP9MM); % Test 7 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP9RMS); % Test 7 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP10MM); % Test 7 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP10RMS); % Test 7 RMS amplitude
% Perform FFT (Fast Fourier Transform) for OWCWP1 to OWCWP10
% The FFT is computed to analyze the frequency domain characteristics of the water column displacement.

% FFT for OWCWP1
L = length(OWCWP1); % Length of the displacement data for OWCWP1
freqres = Fs / L; % Frequency resolution for OWCWP1
freqvec = (0:L-1) * freqres; % Frequency vector for OWCWP1
fftmag = 2 * abs(fft(OWCWP1)) / L; % FFT magnitude for OWCWP1, scaled by the signal length

% FFT for OWCWP2
L2 = length(OWCWP2); % Length of the displacement data for OWCWP2
freqres2 = Fs / L2; % Frequency resolution for OWCWP2
freqvec2 = (0:L2-1) * freqres2; % Frequency vector for OWCWP2
fftmag2 = 2 * abs(fft(OWCWP2)) / L2; % FFT magnitude for OWCWP2, scaled by the signal length

% FFT for OWCWP3
L3 = length(OWCWP3); % Length of the displacement data for OWCWP3
freqres3 = Fs / L3; % Frequency resolution for OWCWP3
freqvec3 = (0:L3-1) * freqres3; % Frequency vector for OWCWP3
fftmag3 = 2 * abs(fft(OWCWP3)) / L3; % FFT magnitude for OWCWP3, scaled by the signal length

% FFT for OWCWP4
L4 = length(OWCWP4); % Length of the displacement data for OWCWP4
freqres4 = Fs / L4; % Frequency resolution for OWCWP4
freqvec4 = (0:L4-1) * freqres4; % Frequency vector for OWCWP4
fftmag4 = 2 * abs(fft(OWCWP4)) / L4; % FFT magnitude for OWCWP4, scaled by the signal length

% FFT for OWCWP5
L5 = length(OWCWP5); % Length of the displacement data for OWCWP5
freqres5 = Fs / L5; % Frequency resolution for OWCWP5
freqvec5 = (0:L5-1) * freqres5; % Frequency vector for OWCWP5
fftmag5 = 2 * abs(fft(OWCWP5)) / L5; % FFT magnitude for OWCWP5, scaled by the signal length

% FFT for OWCWP6
L6 = length(OWCWP6); % Length of the displacement data for OWCWP6
freqres6 = Fs / L6; % Frequency resolution for OWCWP6
freqvec6 = (0:L6-1) * freqres6; % Frequency vector for OWCWP6
fftmag6 = 2 * abs(fft(OWCWP6)) / L6; % FFT magnitude for OWCWP6, scaled by the signal length

% FFT for OWCWP7
L7 = length(OWCWP7); % Length of the displacement data for OWCWP7
freqres7 = Fs / L7; % Frequency resolution for OWCWP7
freqvec7 = (0:L7-1) * freqres7; % Frequency vector for OWCWP7
fftmag7 = 2 * abs(fft(OWCWP7)) / L7; % FFT magnitude for OWCWP7, scaled by the signal length

% FFT for OWCWP8
L8 = length(OWCWP8); % Length of the displacement data for OWCWP8
freqres8 = Fs / L8; % Frequency resolution for OWCWP8
freqvec8 = (0:L8-1) * freqres8; % Frequency vector for OWCWP8
fftmag8 = 2 * abs(fft(OWCWP8)) / L8; % FFT magnitude for OWCWP8, scaled by the signal length

% FFT for OWCWP9
L9 = length(OWCWP9); % Length of the displacement data for OWCWP9
freqres9 = Fs / L9; % Frequency resolution for OWCWP9
freqvec9 = (0:L9-1) * freqres9; % Frequency vector for OWCWP9
fftmag9 = 2 * abs(fft(OWCWP9)) / L9; % FFT magnitude for OWCWP9, scaled by the signal length

% FFT for OWCWP10
L10 = length(OWCWP10); % Length of the displacement data for OWCWP10
freqres10 = Fs / L10; % Frequency resolution for OWCWP10
freqvec10 = (0:L10-1) * freqres10; % Frequency vector for OWCWP10
fftmag10 = 2 * abs(fft(OWCWP10)) / L10; % FFT magnitude for OWCWP10, scaled by the signal length

% Plot FFT results for each test

figure(); % Create a new figure for OWCWP1
plot(freqvec, fftmag); % Plot frequency vs FFT magnitude for OWCWP1
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP1'); % Add a title to the plot

figure(); % Create a new figure for OWCWP2
plot(freqvec2, fftmag2); % Plot frequency vs FFT magnitude for OWCWP2
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP2'); % Add a title to the plot

figure(); % Create a new figure for OWCWP3
plot(freqvec3, fftmag3); % Plot frequency vs FFT magnitude for OWCWP3
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP3'); % Add a title to the plot

figure(); % Create a new figure for OWCWP4
plot(freqvec4, fftmag4); % Plot frequency vs FFT magnitude for OWCWP4
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP4'); % Add a title to the plot

figure(); % Create a new figure for OWCWP5
plot(freqvec5, fftmag5); % Plot frequency vs FFT magnitude for OWCWP5
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP5'); % Add a title to the plot

figure(); % Create a new figure for OWCWP6
plot(freqvec6, fftmag6); % Plot frequency vs FFT magnitude for OWCWP6
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP6'); % Add a title to the plot

figure(); % Create a new figure for OWCWP7
plot(freqvec7, fftmag7); % Plot frequency vs FFT magnitude for OWCWP7
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP7'); % Add a title to the plot

figure(); % Create a new figure for OWCWP8
plot(freqvec8, fftmag8); % Plot frequency vs FFT magnitude for OWCWP8
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP8'); % Add a title to the plot

figure(); % Create a new figure for OWCWP9
plot(freqvec9, fftmag9); % Plot frequency vs FFT magnitude for OWCWP9
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP9'); % Add a title to the plot

figure(); % Create a new figure for OWCWP10
plot(freqvec10, fftmag10); % Plot frequency vs FFT magnitude for OWCWP10
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWCWP10'); % Add a title to the plot

figure(); % Create a new figure for all FFT graphs
hold on; % Allow multiple plots on the same figure

% Plot FFT for OWCWP1
plot(freqvec, fftmag, 'r', 'LineWidth', 1.5); % Red color for Test 1

% Plot FFT for OWCWP2
plot(freqvec2, fftmag2, 'g', 'LineWidth', 1.5); % Green color for Test 2

% Plot FFT for OWCWP3
plot(freqvec3, fftmag3, 'b', 'LineWidth', 1.5); % Blue color for Test 3

% Plot FFT for OWCWP4
plot(freqvec4, fftmag4, 'm', 'LineWidth', 1.5); % Magenta color for Test 4

% Plot FFT for OWCWP5
plot(freqvec5, fftmag5, 'c', 'LineWidth', 1.5); % Cyan color for Test 5

% Plot FFT for OWCWP6
plot(freqvec6, fftmag6, 'k', 'LineWidth', 1.5); % Black color for Test 6

% Plot FFT for OWCWP7
plot(freqvec7, fftmag7, 'y', 'LineWidth', 1.5); % Yellow color for Test 7

% Plot FFT for OWCWP8
plot(freqvec8, fftmag8, 'r--', 'LineWidth', 1.5); % Dashed red line for Test 8

% Plot FFT for OWCWP9
plot(freqvec9, fftmag9, 'g--', 'LineWidth', 1.5); % Dashed green line for Test 9

% Plot FFT for OWCWP10
plot(freqvec10, fftmag10, 'b--', 'LineWidth', 1.5); % Dashed blue line for Test 10

% Customize the figure
xlim([0 3]); % Limit x-axis to the range [0, 3]
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('FFT Magnitude'); % Label the y-axis
title('FFT of OWC Displacement for All Tests'); % Add a title to the plot
legend({'Test 1: 0.4 Hz', 'Test 2: 0.5 Hz', 'Test 3: 0.6 Hz', 'Test 4: 0.7 Hz', ...
        'Test 5: 0.8 Hz', 'Test 6: 0.9 Hz', 'Test 7: 1.0 Hz', 'Test 8: 1.1 Hz', ...
        'Test 9: 1.2 Hz', 'Test 10: 1.3 Hz'}, 'Location', 'northeast'); % Add a legend
grid on; % Add grid lines for better visualization

hold off; % Stop adding plots to this figure


% Calculate the maximum FFT magnitude for each test
% The maximum FFT magnitude represents the peak amplitude in the frequency domain.
AMP1FFT = max(fftmag); % Peak FFT magnitude for test 1
AMP2FFT = max(fftmag2); % Peak FFT magnitude for test 2
AMP3FFT = max(fftmag3); % Peak FFT magnitude for test 3
AMP4FFT = max(fftmag4); % Peak FFT magnitude for test 4
AMP5FFT = max(fftmag5); % Peak FFT magnitude for test 5
AMP6FFT = max(fftmag6); % Peak FFT magnitude for test 6
AMP7FFT = max(fftmag7); % Peak FFT magnitude for test 7
AMP8FFT = max(fftmag8); % Peak FFT magnitude for test 8
AMP9FFT = max(fftmag9); % Peak FFT magnitude for test 9
AMP10FFT = max(fftmag10); % Peak FFT magnitude for test 10

% Calculate the Response Amplitude Operator (RAO) for each test
% RAO is calculated as the peak FFT magnitude divided by the wave amplitude (Wamp).
RAO1 = AMP1FFT / Wamp; % RAO for test 1
RAO2 = AMP2FFT / Wamp; % RAO for test 2
RAO3 = AMP3FFT / Wamp; % RAO for test 3
RAO4 = AMP4FFT / Wamp; % RAO for test 4
RAO5 = AMP5FFT / Wamp; % RAO for test 5
RAO6 = AMP6FFT / Wamp; % RAO for test 6
RAO7 = AMP7FFT / Wamp; % RAO for test 7
RAO8 = AMP8FFT / Wamp; % RAO for test 8
RAO9 = AMP9FFT / Wamp; % RAO for test 9
RAO10 = AMP10FFT / Wamp; % RAO for test 10
RAOVEC = [RAO1, RAO2, RAO3, RAO4, RAO5, RAO6, RAO7, RAO8, RAO9, RAO10]; % Combine RAO values into a vector

% Calculate the RMS power for each test
% RMS power is calculated from the instantaneous power values.
PRMS1 = rms(Pow1); % RMS power for test 1
PRMS2 = rms(Pow2); % RMS power for test 2
PRMS3 = rms(Pow3); % RMS power for test 3
PRMS4 = rms(Pow4); % RMS power for test 4
PRMS5 = rms(Pow5); % RMS power for test 5
PRMS6 = rms(Pow6); % RMS power for test 6
PRMS7 = rms(Pow7); % RMS power for test 7
PRMS8 = rms(Pow8); % RMS power for test 8
PRMS9 = rms(Pow9); % RMS power for test 9
PRMS10 = rms(Pow10); % RMS power for test 10
PRMSVEC = [PRMS1, PRMS2, PRMS3, PRMS4, PRMS5, PRMS6, PRMS7, PRMS8, PRMS9, PRMS10]; % Combine RMS power values into a vector

% Plot chamber pressure for test 2
figure(); % Create a new figure
plot(time2, press2, 'r', 'linewidth', 2); % Plot pressure data for test 2
xlabel('Time (s)'); % Label the x-axis
ylabel('Pressure (Pa)'); % Label the y-axis
title('Chamber Pressure Over Time (Test 2)'); % Add a title
grid on; % Enable grid lines
legend('0.5 Hz'); % Add a legend
xlim([10 20]); % Set x-axis limits

figure(); % Create a new figure for all pressure graphs
hold on; % Allow multiple plots on the same figure

% Plot pressure for all tests
plot(time1, press1, 'r', 'LineWidth', 1.5); % Red line for Test 1
plot(time2, press2, 'g', 'LineWidth', 1.5); % Green line for Test 2
plot(time3, press3, 'b', 'LineWidth', 1.5); % Blue line for Test 3
plot(time4, press4, 'm', 'LineWidth', 1.5); % Magenta line for Test 4
plot(time5, press5, 'c', 'LineWidth', 1.5); % Cyan line for Test 5
plot(time6, press6, 'k', 'LineWidth', 1.5); % Black line for Test 6
plot(time7, press7, 'y', 'LineWidth', 1.5); % Yellow line for Test 7
plot(time8, press8, 'r--', 'LineWidth', 1.5); % Dashed red line for Test 8
plot(time9, press9, 'g--', 'LineWidth', 1.5); % Dashed green line for Test 9
plot(time10, press10, 'b--', 'LineWidth', 1.5); % Dashed blue line for Test 10

% Customize the figure
xlabel('Time (s)'); % Label the x-axis
ylabel('Pressure (Pa)'); % Label the y-axis
title('Chamber Pressure Over Time for All Tests'); % Add a title
legend({'Test 1: 0.4 Hz', 'Test 2: 0.5 Hz', 'Test 3: 0.6 Hz', 'Test 4: 0.7 Hz', ...
        'Test 5: 0.8 Hz', 'Test 6: 0.9 Hz', 'Test 7: 1.0 Hz', 'Test 8: 1.1 Hz', ...
        'Test 9: 1.2 Hz', 'Test 10: 1.3 Hz'}, 'Location', 'northeast'); % Add a legend
grid on; % Add grid lines
xlim([10 20]); % Set x-axis limits for the time interval of interest

hold off; % Stop adding plots to this figure

% Plot mass flow rate for test 1
figure(); % Create a new figure
plot(time1, mdot1, 'r', 'linewidth', 2); % Plot mass flow rate data for test 1
xlabel('Time (s)'); % Label the x-axis
ylabel('Mass Flow Rate (kg/s)'); % Label the y-axis
title('Mass Flow Rate Over Time (Test 1)'); % Add a title
grid on; % Enable grid lines
legend('0.4 Hz'); % Add a legend
xlim([10 20]); % Set x-axis limits
figure(); % Create a new figure for all mass flow rate graphs
hold on; % Allow multiple plots on the same figure

% Plot mass flow rate for all tests
plot(time1, mdot1, 'r', 'LineWidth', 1.5); % Red line for Test 1
plot(time2, mdot2, 'g', 'LineWidth', 1.5); % Green line for Test 2
plot(time3, mdot3, 'b', 'LineWidth', 1.5); % Blue line for Test 3
plot(time4, mdot4, 'm', 'LineWidth', 1.5); % Magenta line for Test 4
plot(time5, mdot5, 'c', 'LineWidth', 1.5); % Cyan line for Test 5
plot(time6, mdot6, 'k', 'LineWidth', 1.5); % Black line for Test 6
plot(time7, mdot7, 'y', 'LineWidth', 1.5); % Yellow line for Test 7
plot(time8, mdot8, 'r--', 'LineWidth', 1.5); % Dashed red line for Test 8
plot(time9, mdot9, 'g--', 'LineWidth', 1.5); % Dashed green line for Test 9
plot(time10, mdot10, 'b--', 'LineWidth', 1.5); % Dashed blue line for Test 10

% Customize the figure
xlabel('Time (s)'); % Label the x-axis
ylabel('Mass Flow Rate (kg/s)'); % Label the y-axis
title('Mass Flow Rate Over Time for All Tests'); % Add a title
legend({'Test 1: 0.4 Hz', 'Test 2: 0.5 Hz', 'Test 3: 0.6 Hz', 'Test 4: 0.7 Hz', ...
        'Test 5: 0.8 Hz', 'Test 6: 0.9 Hz', 'Test 7: 1.0 Hz', 'Test 8: 1.1 Hz', ...
        'Test 9: 1.2 Hz', 'Test 10: 1.3 Hz'}, 'Location', 'northeast'); % Add a legend
grid on; % Enable grid lines
xlim([10 20]); % Set x-axis limits for the time interval of interest

hold off; % Stop adding plots to this figure


% Plot volumetric flow rate for test 1
figure(); % Create a new figure
plot(time1, Q1, 'r', 'linewidth', 2); % Plot volumetric flow rate data for test 1
xlabel('Time (s)'); % Label the x-axis
ylabel('Volume Flow Rate (m^3/s)'); % Label the y-axis
title('Volumetric Flow Rate Over Time (Test 1)'); % Add a title
grid on; % Enable grid lines
legend('0.4 Hz'); % Add a legend
xlim([10 20]); % Set x-axis limits
figure(); % Create a new figure for all volumetric flow rate graphs
hold on; % Allow multiple plots on the same figure

% Plot volumetric flow rate for all tests
plot(time1, Q1, 'r', 'LineWidth', 1.5); % Red line for Test 1
plot(time2, Q2, 'g', 'LineWidth', 1.5); % Green line for Test 2
plot(time3, Q3, 'b', 'LineWidth', 1.5); % Blue line for Test 3
plot(time4, Q4, 'm', 'LineWidth', 1.5); % Magenta line for Test 4
plot(time5, Q5, 'c', 'LineWidth', 1.5); % Cyan line for Test 5
plot(time6, Q6, 'k', 'LineWidth', 1.5); % Black line for Test 6
plot(time7, Q7, 'y', 'LineWidth', 1.5); % Yellow line for Test 7
plot(time8, Q8, 'r--', 'LineWidth', 1.5); % Dashed red line for Test 8
plot(time9, Q9, 'g--', 'LineWidth', 1.5); % Dashed green line for Test 9
plot(time10, Q10, 'b--', 'LineWidth', 1.5); % Dashed blue line for Test 10

% Customize the figure
xlabel('Time (s)'); % Label the x-axis
ylabel('Volume Flow Rate (m^3/s)'); % Label the y-axis
title('Volumetric Flow Rate Over Time for All Tests'); % Add a title
legend({'Test 1: 0.4 Hz', 'Test 2: 0.5 Hz', 'Test 3: 0.6 Hz', 'Test 4: 0.7 Hz', ...
        'Test 5: 0.8 Hz', 'Test 6: 0.9 Hz', 'Test 7: 1.0 Hz', 'Test 8: 1.1 Hz', ...
        'Test 9: 1.2 Hz', 'Test 10: 1.3 Hz'}, 'Location', 'northeast'); % Add a legend
grid on; % Enable grid lines
xlim([10 20]); % Set x-axis limits for the time interval of interest

hold off; % Stop adding plots to this figure


% Plot absorbed power for test 1
figure(); % Create a new figure
plot(time1, Pow1, 'r', 'linewidth', 2); % Plot absorbed power data for test 1
xlabel('Time (s)'); % Label the x-axis
ylabel('Power (W)'); % Label the y-axis
title('Absorbed Power Over Time (Test 1)'); % Add a title
grid on; % Enable grid lines
legend('0.4 Hz'); % Add a legend
xlim([10 20]); % Set x-axis limits

figure(); % Create a new figure for all absorbed power graphs
hold on; % Allow multiple plots on the same figure

% Plot absorbed power for all tests
plot(time1, Pow1, 'r', 'LineWidth', 1.5); % Red line for Test 1
plot(time2, Pow2, 'g', 'LineWidth', 1.5); % Green line for Test 2
plot(time3, Pow3, 'b', 'LineWidth', 1.5); % Blue line for Test 3
plot(time4, Pow4, 'm', 'LineWidth', 1.5); % Magenta line for Test 4
plot(time5, Pow5, 'c', 'LineWidth', 1.5); % Cyan line for Test 5
plot(time6, Pow6, 'k', 'LineWidth', 1.5); % Black line for Test 6
plot(time7, Pow7, 'y', 'LineWidth', 1.5); % Yellow line for Test 7
plot(time8, Pow8, 'r--', 'LineWidth', 1.5); % Dashed red line for Test 8
plot(time9, Pow9, 'g--', 'LineWidth', 1.5); % Dashed green line for Test 9
plot(time10, Pow10, 'b--', 'LineWidth', 1.5); % Dashed blue line for Test 10

% Customize the figure
xlabel('Time (s)'); % Label the x-axis
ylabel('Power (W)'); % Label the y-axis
title('Absorbed Power Over Time for All Tests'); % Add a title
legend({'Test 1: 0.4 Hz', 'Test 2: 0.5 Hz', 'Test 3: 0.6 Hz', 'Test 4: 0.7 Hz', ...
        'Test 5: 0.8 Hz', 'Test 6: 0.9 Hz', 'Test 7: 1.0 Hz', 'Test 8: 1.1 Hz', ...
        'Test 9: 1.2 Hz', 'Test 10: 1.3 Hz'}, 'Location', 'northeast'); % Add a legend
grid on; % Enable grid lines
xlim([10 20]); % Set x-axis limits for the time interval of interest

hold off; % Stop adding plots to this figure


% Plot water column displacement for test 1
figure(); % Create a new figure
plot(time1, OWCWP1, 'r', 'linewidth', 2); % Plot water column displacement data for test 1
xlabel('Time (s)'); % Label the x-axis
ylabel('Displacement (m)'); % Label the y-axis
title('Water Column Displacement Over Time (Test 1)'); % Add a title
grid on; % Enable grid lines
legend('0.4 Hz'); % Add a legend
xlim([10 20]); % Set x-axis limits

figure(); % Create a new figure for all water column displacement graphs
hold on; % Allow multiple plots on the same figure

% Plot water column displacement for all tests
plot(time1, OWCWP1, 'r', 'LineWidth', 1.5); % Test 1 (Red line)
plot(time2, OWCWP2, 'g', 'LineWidth', 1.5); % Test 2 (Green line)
plot(time3, OWCWP3, 'b', 'LineWidth', 1.5); % Test 3 (Blue line)
plot(time4, OWCWP4, 'm', 'LineWidth', 1.5); % Test 4 (Magenta line)
plot(time5, OWCWP5, 'c', 'LineWidth', 1.5); % Test 5 (Cyan line)
plot(time6, OWCWP6, 'k', 'LineWidth', 1.5); % Test 6 (Black line)
plot(time7, OWCWP7, 'y', 'LineWidth', 1.5); % Test 7 (Yellow line)
plot(time8, OWCWP8, 'r--', 'LineWidth', 1.5); % Test 8 (Dashed red line)
plot(time9, OWCWP9, 'g--', 'LineWidth', 1.5); % Test 9 (Dashed green line)
plot(time10, OWCWP10, 'b--', 'LineWidth', 1.5); % Test 10 (Dashed blue line)

% Customize the plot
xlabel('Time (s)'); % Label the x-axis
ylabel('Displacement (m)'); % Label the y-axis
title('Water Column Displacement Over Time for All Tests'); % Add a title
legend({'Test 1: 0.4 Hz', 'Test 2: 0.5 Hz', 'Test 3: 0.6 Hz', 'Test 4: 0.7 Hz', ...
        'Test 5: 0.8 Hz', 'Test 6: 0.9 Hz', 'Test 7: 1.0 Hz', 'Test 8: 1.1 Hz', ...
        'Test 9: 1.2 Hz', 'Test 10: 1.3 Hz'}, 'Location', 'northeast'); % Add a legend
grid on; % Enable grid lines
xlim([10 20]); % Set x-axis limits to focus on the interval of interest

hold off; % Stop adding plots to the figure

% Plot RMS power vs frequency
figure(); % Create a new figure
plot(freq, PRMSVEC, 'r', 'linewidth', 2); % Plot RMS power vs frequency
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('RMS Power (W)'); % Label the y-axis
title('RMS Power vs Frequency'); % Add a title
grid on; % Enable grid lines

% Plot RAO vs frequency
figure(); % Create a new figure
plot(freq, RAOVEC, 'r', 'linewidth', 2); % Plot RAO vs frequency
xlabel('Frequency (Hz)'); % Label the x-axis
ylabel('RAO (m/m)'); % Label the y-axis
title('RAO vs Frequency'); % Add a title
grid on; % Enable grid lines
