function testdatazerod = zeroer(path1,path2)
% This function takes two file paths as input. It assumes the first is a
% stillwater file, and the second is a data file both already converted to
% '.tom'. It then averaged the stillwate data and subtracts it from the
% test data. Returned is a matrix of the 'zero'd' test data
    
stilldata = textread(sprintf(path1));
stiller = mean(stilldata);
testdata = textread(sprintf(path2));
[~,n] = size(stiller);
testdatazerod(:,1) = testdata(:,1);
for cnt = 2:n
    testdatazerod(:,cnt) = testdata(:,cnt) - stiller(cnt);
end
end