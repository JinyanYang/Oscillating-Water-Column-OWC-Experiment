clc  
close all           
clear 