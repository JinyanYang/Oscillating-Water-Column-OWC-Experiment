clc;  % Clear the command window
close all;  % Close all figure windows
clear;  % Clear all variables from the workspace

% Constants for the experiment
rhow = 1000; % Density of water (kg/m^3)
rhoa = 1.227; % Density of air (kg/m^3)
grav = 9.81; % Gravitational acceleration (m/s^2)
odia = [10E-3:5E-3:40E-3]; % Array of orifice diameters (m)
Wamp = 30E-3; % Wave amplitude (m)
A = pi * odia.^2 / 4; % Orifice area (m^2)
Cd = 0.62; % Discharge coefficient
Fs = 128; % Sampling frequency (Hz)
freq = 0.8; % Wave frequency (Hz)


% path = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\stillwater.tom';
% path1 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz10mmori.tom';
% path2 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz15mmori.tom';
% path3 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz20mmori.tom';
% path4 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz25mmori.tom';
% path5 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz30mmori.tom';
% path6 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz35mmori.tom';
% path7 = 'C:\\Users\\d00264564\\Desktop\\CA2\\damp hunt\\30mm08hz40mmori.tom';

% File paths for data
path = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\stillwater.tom';
path1 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz10mmori.tom';
path2 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz15mmori.tom';
path3 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz20mmori.tom';
path4 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz25mmori.tom';
path5 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz30mmori.tom';
path6 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz35mmori.tom';
path7 = 'D:\\YJY Assignments\\Master\\Water\\CA2 OWC Experiment\\CA2\\damp hunt\\30mm08hz40mmori.tom';

% Import and calibrate data for each test
% The `zeroer` function is used to calibrate the test data by removing offsets from the stillwater baseline data.
data1 = zeroer(path, path1); % Calibrate test data from path1
data2 = zeroer(path, path2); % Calibrate test data from path2
data3 = zeroer(path, path3); % Calibrate test data from path3
data4 = zeroer(path, path4); % Calibrate test data from path4
data5 = zeroer(path, path5); % Calibrate test data from path5
data6 = zeroer(path, path6); % Calibrate test data from path6
data7 = zeroer(path, path7); % Calibrate test data from path7

% Extract time vectors from each dataset
% Each dataset contains time as the first column. This extracts the time series for each test.
time1 = data1(:,1); % Time vector for test 1
time2 = data2(:,1); % Time vector for test 2
time3 = data3(:,1); % Time vector for test 3
time4 = data4(:,1); % Time vector for test 4
time5 = data5(:,1); % Time vector for test 5
time6 = data6(:,1); % Time vector for test 6
time7 = data7(:,1); % Time vector for test 7

% Calculate pressure for each test (Pa)
% The pressure is calculated from the fourth column of each dataset, which contains pressure data in mmH?O.
% The conversion from mmH2O to Pascal is performed using water density and gravitational acceleration.
press1 = rhow * grav * data1(:,4) / 1000; % Pressure for test 1
press2 = rhow * grav * data2(:,4) / 1000; % Pressure for test 2
press3 = rhow * grav * data3(:,4) / 1000; % Pressure for test 3
press4 = rhow * grav * data4(:,4) / 1000; % Pressure for test 4
press5 = rhow * grav * data5(:,4) / 1000; % Pressure for test 5
press6 = rhow * grav * data6(:,4) / 1000; % Pressure for test 6
press7 = rhow * grav * data7(:,4) / 1000; % Pressure for test 7

% Calculate mass flow rate for each test (kg/s)
% The mass flow rate is calculated using the orifice equation: Cd*A*sqrt(2*rhoa*abs(press)).
% The `sign` function ensures the flow direction is correctly assigned.
mdot1 = Cd * A(1) * sqrt(2 * rhoa * abs(press1)) .* sign(press1); % Mass flow rate for test 1
mdot2 = Cd * A(2) * sqrt(2 * rhoa * abs(press2)) .* sign(press2); % Mass flow rate for test 2
mdot3 = Cd * A(3) * sqrt(2 * rhoa * abs(press3)) .* sign(press3); % Mass flow rate for test 3
mdot4 = Cd * A(4) * sqrt(2 * rhoa * abs(press4)) .* sign(press4); % Mass flow rate for test 4
mdot5 = Cd * A(5) * sqrt(2 * rhoa * abs(press5)) .* sign(press5); % Mass flow rate for test 5
mdot6 = Cd * A(6) * sqrt(2 * rhoa * abs(press6)) .* sign(press6); % Mass flow rate for test 6
mdot7 = Cd * A(7) * sqrt(2 * rhoa * abs(press7)) .* sign(press7); % Mass flow rate for test 7


% Calculate volumetric flow rate for each test (m^3/s)
% Volumetric flow rate is derived by dividing mass flow rate by air density.
Q1 = mdot1 / rhoa; % Volumetric flow rate for test 1
Q2 = mdot2 / rhoa; % Volumetric flow rate for test 2
Q3 = mdot3 / rhoa; % Volumetric flow rate for test 3
Q4 = mdot4 / rhoa; % Volumetric flow rate for test 4
Q5 = mdot5 / rhoa; % Volumetric flow rate for test 5
Q6 = mdot6 / rhoa; % Volumetric flow rate for test 6
Q7 = mdot7 / rhoa; % Volumetric flow rate for test 7

% Calculate absorbed power for each test (W)
% Absorbed power is computed as the product of volumetric flow rate and pressure, taking the absolute value.
Pow1 = abs(Q1 .* press1); % Absorbed power for test 1
Pow2 = abs(Q2 .* press2); % Absorbed power for test 2
Pow3 = abs(Q3 .* press3); % Absorbed power for test 3
Pow4 = abs(Q4 .* press4); % Absorbed power for test 4
Pow5 = abs(Q5 .* press5); % Absorbed power for test 5
Pow6 = abs(Q6 .* press6); % Absorbed power for test 6
Pow7 = abs(Q7 .* press7); % Absorbed power for test 7

% Extract water column displacement for each test (m)
% Water column displacement data is extracted from the third column of each dataset and converted from mm to m.
OWCWP1 = data1(:,3) / 1000; % Water column displacement for test 1
OWCWP2 = data2(:,3) / 1000; % Water column displacement for test 2
OWCWP3 = data3(:,3) / 1000; % Water column displacement for test 3
OWCWP4 = data4(:,3) / 1000; % Water column displacement for test 4
OWCWP5 = data5(:,3) / 1000; % Water column displacement for test 5
OWCWP6 = data6(:,3) / 1000; % Water column displacement for test 6
OWCWP7 = data7(:,3) / 1000; % Water column displacement for test 7

% Calculate peak-to-peak amplitude and RMS for each test
% Peak-to-peak amplitude is computed as half the difference between the maximum and minimum displacement.
% RMS amplitude is calculated as the root mean square (RMS) multiplied by sqrt(2).
AMP1MM = (max(OWCWP1) - min(OWCWP1)) / 2; % Peak-to-peak amplitude for test 1
AMP2MM = (max(OWCWP2) - min(OWCWP2)) / 2; % Peak-to-peak amplitude for test 2
AMP3MM = (max(OWCWP3) - min(OWCWP3)) / 2; % Peak-to-peak amplitude for test 3
AMP4MM = (max(OWCWP4) - min(OWCWP4)) / 2; % Peak-to-peak amplitude for test 4
AMP5MM = (max(OWCWP5) - min(OWCWP5)) / 2; % Peak-to-peak amplitude for test 5
AMP6MM = (max(OWCWP6) - min(OWCWP6)) / 2; % Peak-to-peak amplitude for test 6
AMP7MM = (max(OWCWP7) - min(OWCWP7)) / 2; % Peak-to-peak amplitude for test 7

AMP1RMS = sqrt(2) * rms(OWCWP1); % RMS amplitude for test 1
AMP2RMS = sqrt(2) * rms(OWCWP2); % RMS amplitude for test 2
AMP3RMS = sqrt(2) * rms(OWCWP3); % RMS amplitude for test 3
AMP4RMS = sqrt(2) * rms(OWCWP4); % RMS amplitude for test 4
AMP5RMS = sqrt(2) * rms(OWCWP5); % RMS amplitude for test 5
AMP6RMS = sqrt(2) * rms(OWCWP6); % RMS amplitude for test 6
AMP7RMS = sqrt(2) * rms(OWCWP7); % RMS amplitude for test 7

% Display calculated amplitudes
% Display both peak-to-peak and RMS amplitudes for all tests for validation and comparison.
disp('Amp of OWC using max/min is'); disp(AMP1MM); % Test 1 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP1RMS); % Test 1 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP2MM); % Test 2 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP2RMS); % Test 2 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP3MM); % Test 3 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP3RMS); % Test 3 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP4MM); % Test 4 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP4RMS); % Test 4 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP5MM); % Test 5 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP5RMS); % Test 5 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP6MM); % Test 6 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP6RMS); % Test 6 RMS amplitude

disp('Amp of OWC using max/min is'); disp(AMP7MM); % Test 7 peak-to-peak amplitude
disp('Amp of OWC using RMS approach is'); disp(AMP7RMS); % Test 7 RMS amplitude

% Calculate the FFT (Fast Fourier Transform) of water column displacement (OWCWP1)
L = length(OWCWP1); % Length of the displacement data for test 1
freqres = Fs / L; % Frequency resolution for test 1
freqvec = (0:L-1) * freqres; % Frequency vector for test 1
fftmag = 2 * abs(fft(OWCWP1)) / L; % FFT magnitude for test 1, scaled by the data length

% Calculate the FFT of OWCWP2
L2 = length(OWCWP2); % Length of the displacement data for test 2
freqres2 = Fs / L2; % Frequency resolution for test 2
freqvec2 = (0:L2-1) * freqres2; % Frequency vector for test 2
fftmag2 = 2 * abs(fft(OWCWP2)) / L2; % FFT magnitude for test 2, scaled by the data length

% Calculate the FFT of OWCWP3
L3 = length(OWCWP3); % Length of the displacement data for test 3
freqres3 = Fs / L3; % Frequency resolution for test 3
freqvec3 = (0:L3-1) * freqres3; % Frequency vector for test 3
fftmag3 = 2 * abs(fft(OWCWP3)) / L3; % FFT magnitude for test 3, scaled by the data length

% Calculate the FFT of OWCWP4
L4 = length(OWCWP4); % Length of the displacement data for test 4
freqres4 = Fs / L4; % Frequency resolution for test 4
freqvec4 = (0:L4-1) * freqres4; % Frequency vector for test 4
fftmag4 = 2 * abs(fft(OWCWP4)) / L4; % FFT magnitude for test 4, scaled by the data length

% Calculate the FFT of OWCWP5
L5 = length(OWCWP5); % Length of the displacement data for test 5
freqres5 = Fs / L5; % Frequency resolution for test 5
freqvec5 = (0:L5-1) * freqres5; % Frequency vector for test 5
fftmag5 = 2 * abs(fft(OWCWP5)) / L5; % FFT magnitude for test 5, scaled by the data length

% Calculate the FFT of OWCWP6
L6 = length(OWCWP6); % Length of the displacement data for test 6
freqres6 = Fs / L6; % Frequency resolution for test 6
freqvec6 = (0:L6-1) * freqres6; % Frequency vector for test 6
fftmag6 = 2 * abs(fft(OWCWP6)) / L6; % FFT magnitude for test 6, scaled by the data length

% Calculate the FFT of OWCWP7
L7 = length(OWCWP7); % Length of the displacement data for test 7
freqres7 = Fs / L7; % Frequency resolution for test 7
freqvec7 = (0:L7-1) * freqres7; % Frequency vector for test 7
fftmag7 = 2 * abs(fft(OWCWP7)) / L7; % FFT magnitude for test 7, scaled by the data length

% Plot FFT results for each test
figure(); % Create a new figure for test 1
plot(freqvec, fftmag, 'LineWidth', 2); % Plot FFT magnitude for test 1
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 1)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3]

figure(); % Create a new figure for test 2
plot(freqvec2, fftmag2, 'LineWidth', 2); % Plot FFT magnitude for test 2
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 2)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3]

figure(); % Create a new figure for test 3
plot(freqvec3, fftmag3, 'LineWidth', 2); % Plot FFT magnitude for test 3
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 3)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3]

figure(); % Create a new figure for test 4
plot(freqvec4, fftmag4, 'LineWidth', 2); % Plot FFT magnitude for test 4
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 4)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3]

figure(); % Create a new figure for test 5
plot(freqvec5, fftmag5, 'LineWidth', 2); % Plot FFT magnitude for test 5
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 5)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3]

figure(); % Create a new figure for test 6
plot(freqvec6, fftmag6, 'LineWidth', 2); % Plot FFT magnitude for test 6
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 6)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3]

figure(); % Create a new figure for test 7
plot(freqvec7, fftmag7, 'LineWidth', 2); % Plot FFT magnitude for test 7
xlabel('Frequency (Hz)'); % X-axis label
ylabel('FFT Magnitude'); % Y-axis label
title('FFT of OWC Displacement (Test 7)'); % Title of the plot
grid on; % Add grid lines
xlim([0 3]); % Limit X-axis to [0, 3])

% Create a new figure for the FFT of all tests
figure();
hold on; % Allow multiple plots on the same figure

% Plot the FFT results for each test
plot(freqvec, fftmag, 'r', 'LineWidth', 1.5); % FFT for test 1
plot(freqvec2, fftmag2, 'g', 'LineWidth', 1.5); % FFT for test 2
plot(freqvec3, fftmag3, 'b', 'LineWidth', 1.5); % FFT for test 3
plot(freqvec4, fftmag4, 'm', 'LineWidth', 1.5); % FFT for test 4
plot(freqvec5, fftmag5, 'c', 'LineWidth', 1.5); % FFT for test 5
plot(freqvec6, fftmag6, 'y', 'LineWidth', 1.5); % FFT for test 6
plot(freqvec7, fftmag7, 'k', 'LineWidth', 1.5); % FFT for test 7

% Add labels, title, grid, and legend
xlabel('Frequency (Hz)'); % Label for the x-axis
ylabel('FFT Magnitude'); % Label for the y-axis
title('FFT of Water Column Displacement for All Tests'); % Title for the plot
grid on; % Add grid lines
% Add legend with test identifiers
legend({'Test 1: 10mm', 'Test 2: 15mm', 'Test 3: 20mm', 'Test 4: 25mm', ...
        'Test 5: 30mm', 'Test 6: 35mm', 'Test 7: 40mm'}, 'Location', 'best');
xlim([0 3]); % Set x-axis limits to [0, 3]

hold off; % Stop adding plots to the current figure


% Calculate the maximum FFT amplitude for each test
AMP1FFT = max(fftmag); % Maximum FFT amplitude for test 1
AMP2FFT = max(fftmag2); % Maximum FFT amplitude for test 2
AMP3FFT = max(fftmag3); % Maximum FFT amplitude for test 3
AMP4FFT = max(fftmag4); % Maximum FFT amplitude for test 4
AMP5FFT = max(fftmag5); % Maximum FFT amplitude for test 5
AMP6FFT = max(fftmag6); % Maximum FFT amplitude for test 6
AMP7FFT = max(fftmag7); % Maximum FFT amplitude for test 7

% Calculate the Response Amplitude Operator (RAO) for each test
RAO1 = AMP1FFT / Wamp; % RAO for test 1
RAO2 = AMP2FFT / Wamp; % RAO for test 2
RAO3 = AMP3FFT / Wamp; % RAO for test 3
RAO4 = AMP4FFT / Wamp; % RAO for test 4
RAO5 = AMP5FFT / Wamp; % RAO for test 5
RAO6 = AMP6FFT / Wamp; % RAO for test 6
RAO7 = AMP7FFT / Wamp; % RAO for test 7

% Store RAO values in a vector for plotting
RAOVEC = [RAO1, RAO2, RAO3, RAO4, RAO5, RAO6, RAO7];

% Calculate the RMS power for each test
PRMS1 = rms(Pow1); % RMS power for test 1
PRMS2 = rms(Pow2); % RMS power for test 2
PRMS3 = rms(Pow3); % RMS power for test 3
PRMS4 = rms(Pow4); % RMS power for test 4
PRMS5 = rms(Pow5); % RMS power for test 5
PRMS6 = rms(Pow6); % RMS power for test 6
PRMS7 = rms(Pow7); % RMS power for test 7

% Store RMS power values in a vector for plotting
PRMSVEC = [PRMS1, PRMS2, PRMS3, PRMS4, PRMS5, PRMS6, PRMS7];

% Plot chamber pressure over time for test 2
figure(); % Create a new figure
plot(time2, press2, 'r', 'LineWidth', 2); % Plot pressure data for test 2
xlabel('Time (s)'); % Label for the x-axis
ylabel('Pressure (Pa)'); % Label for the y-axis
title('Chamber Pressure Over Time (Test 2)'); % Title for the plot
grid on; % Add grid lines
legend('Test 2: 15mm'); % Add a legend
xlim([10 20]); % Limit x-axis to [10, 20]

% Plot chamber pressure over time for all tests on the same graph
figure(); % Create a new figure
hold on; % Enable adding multiple plots to the same figure
plot(time1, press1, 'r', 'LineWidth', 2); % Plot pressure data for test 1
plot(time2, press2, 'b', 'LineWidth', 2); % Plot pressure data for test 2
plot(time3, press3, 'g', 'LineWidth', 2); % Plot pressure data for test 3
plot(time4, press4, 'm', 'LineWidth', 2); % Plot pressure data for test 4
plot(time5, press5, 'c', 'LineWidth', 2); % Plot pressure data for test 5
plot(time6, press6, 'k', 'LineWidth', 2); % Plot pressure data for test 6
plot(time7, press7, 'y', 'LineWidth', 2); % Plot pressure data for test 7
hold off; % Stop adding plots to the figure

% Add labels, title, and legend
xlabel('Time (s)'); % Label for the x-axis
ylabel('Pressure (Pa)'); % Label for the y-axis
title('Chamber Pressure Over Time (All Tests)'); % Title for the plot
grid on; % Add grid lines
legend({'Test 1: 10mm', 'Test 2: 15mm', 'Test 3: 20mm', 'Test 4: 25mm', ...
        'Test 5: 30mm', 'Test 6: 35mm', 'Test 7: 40mm'}, 'Location', 'best'); % Add a legend
xlim([10 20]); % Limit x-axis to [10, 20]

% Plot mass flow rate over time for test 1
figure(); % Create a new figure
plot(time1, mdot1, 'r', 'LineWidth', 2); % Plot mass flow rate data for test 1
xlabel('Time (s)'); % Label for the x-axis
ylabel('Mass Flow Rate (kg/s)'); % Label for the y-axis
title('Mass Flow Rate Over Time (Test 1)'); % Title for the plot
grid on; % Add grid lines
legend('Test 1: 10mm'); % Add a legend
xlim([10 20]); % Limit x-axis to [10, 20]

figure(); % Create a new figure

% Plot each mass flow rate on the same figure
plot(time1, mdot1, 'r', 'LineWidth', 2); hold on; % Plot test 1 in red
plot(time2, mdot2, 'g', 'LineWidth', 2); % Plot test 2 in green
plot(time3, mdot3, 'b', 'LineWidth', 2); % Plot test 3 in blue
plot(time4, mdot4, 'c', 'LineWidth', 2); % Plot test 4 in cyan
plot(time5, mdot5, 'm', 'LineWidth', 2); % Plot test 5 in magenta
plot(time6, mdot6, 'y', 'LineWidth', 2); % Plot test 6 in yellow
plot(time7, mdot7, 'k', 'LineWidth', 2); % Plot test 7 in black

% Add labels, title, and grid
xlabel('Time (s)'); % Label for the x-axis
ylabel('Mass Flow Rate (kg/s)'); % Label for the y-axis
title('Mass Flow Rate Over Time for All Tests'); % Title for the plot
grid on; % Add grid lines

% Add legend with test identifiers
legend({'Test 1: 10mm', 'Test 2: 15mm', 'Test 3: 20mm', 'Test 4: 25mm', ...
        'Test 5: 30mm', 'Test 6: 35mm', 'Test 7: 40mm'}, 'Location', 'best');

% Set x-axis limits if needed
xlim([10 20]); % Limit x-axis to [10, 20]

hold off; % Release the hold on the figure

% Plot volumetric flow rate over time for test 1
figure(); % Create a new figure
plot(time1, Q1, 'r', 'LineWidth', 2); % Plot volumetric flow rate data for test 1
xlabel('Time (s)'); % Label for the x-axis
ylabel('Volume Flow Rate (m^3/s)'); % Label for the y-axis
title('Volumetric Flow Rate Over Time (Test 1)'); % Title for the plot
grid on; % Add grid lines
legend('Test 1: 10mm'); % Add a legend
xlim([10 20]); % Limit x-axis to [10, 20]

figure(); % Create a new figure
% Plot each volumetric flow rate on the same figure
plot(time1, Q1, 'r', 'LineWidth', 2); hold on; % Plot test 1 in red
plot(time2, Q2, 'g', 'LineWidth', 2); % Plot test 2 in green
plot(time3, Q3, 'b', 'LineWidth', 2); % Plot test 3 in blue
plot(time4, Q4, 'c', 'LineWidth', 2); % Plot test 4 in cyan
plot(time5, Q5, 'm', 'LineWidth', 2); % Plot test 5 in magenta
plot(time6, Q6, 'y', 'LineWidth', 2); % Plot test 6 in yellow
plot(time7, Q7, 'k', 'LineWidth', 2); % Plot test 7 in black

% Add labels, title, and grid
xlabel('Time (s)'); % Label for the x-axis
ylabel('Volumetric Flow Rate (m^3/s)'); % Label for the y-axis
title('Volumetric Flow Rate Over Time for All Tests'); % Title for the plot
grid on; % Add grid lines

% Add legend with test identifiers
legend({'Test 1: 10mm', 'Test 2: 15mm', 'Test 3: 20mm', 'Test 4: 25mm', ...
        'Test 5: 30mm', 'Test 6: 35mm', 'Test 7: 40mm'}, 'Location', 'best');

% Set x-axis limits if needed
xlim([10 20]); % Limit x-axis to [10, 20]
hold off; % Release the hold on the figure


% Plot absorbed power over time for test 1
figure(); % Create a new figure
plot(time1, Pow1, 'r', 'LineWidth', 2); % Plot absorbed power data for test 1
xlabel('Time (s)'); % Label for the x-axis
ylabel('Power (W)'); % Label for the y-axis
title('Absorbed Power Over Time (Test 1)'); % Title for the plot
grid on; % Add grid lines
legend('Test 1: 10mm'); % Add a legend
xlim([10 20]); % Limit x-axis to [10, 20]

figure(); % Create a new figure

% Plot each absorbed power curve on the same figure
plot(time1, Pow1, 'r', 'LineWidth', 2); hold on; % Plot test 1 in red
plot(time2, Pow2, 'g', 'LineWidth', 2); % Plot test 2 in green
plot(time3, Pow3, 'b', 'LineWidth', 2); % Plot test 3 in blue
plot(time4, Pow4, 'c', 'LineWidth', 2); % Plot test 4 in cyan
plot(time5, Pow5, 'm', 'LineWidth', 2); % Plot test 5 in magenta
plot(time6, Pow6, 'y', 'LineWidth', 2); % Plot test 6 in yellow
plot(time7, Pow7, 'k', 'LineWidth', 2); % Plot test 7 in black

% Add labels, title, and grid
xlabel('Time (s)'); % Label for the x-axis
ylabel('Absorbed Power (W)'); % Label for the y-axis
title('Absorbed Power Over Time for All Tests'); % Title for the plot
grid on; % Add grid lines

% Add legend with test identifiers
legend({'Test 1: 10mm', 'Test 2: 15mm', 'Test 3: 20mm', 'Test 4: 25mm', ...
        'Test 5: 30mm', 'Test 6: 35mm', 'Test 7: 40mm'}, 'Location', 'best');

% Set x-axis limits if needed
xlim([10 20]); % Limit x-axis to [10, 20]

hold off; % Release the hold on the figure

% Plot water column displacement over time for test 1
figure(); % Create a new figure
plot(time1, OWCWP1, 'r', 'LineWidth', 2); % Plot displacement data for test 1
xlabel('Time (s)'); % Label for the x-axis
ylabel('Displacement (m)'); % Label for the y-axis
title('Water Column Displacement Over Time (Test 1)'); % Title for the plot
grid on; % Add grid lines
legend('Test 1: 10mm'); % Add a legend
xlim([10 20]); % Limit x-axis to [10, 20]

figure(); % Create a new figure

% Plot each water column displacement curve on the same figure
plot(time1, OWCWP1, 'r', 'LineWidth', 2); hold on; % Plot test 1 in red
plot(time2, OWCWP2, 'g', 'LineWidth', 2); % Plot test 2 in green
plot(time3, OWCWP3, 'b', 'LineWidth', 2); % Plot test 3 in blue
plot(time4, OWCWP4, 'c', 'LineWidth', 2); % Plot test 4 in cyan
plot(time5, OWCWP5, 'm', 'LineWidth', 2); % Plot test 5 in magenta
plot(time6, OWCWP6, 'y', 'LineWidth', 2); % Plot test 6 in yellow
plot(time7, OWCWP7, 'k', 'LineWidth', 2); % Plot test 7 in black

% Add labels, title, and grid
xlabel('Time (s)'); % Label for the x-axis
ylabel('Water Column Displacement (m)'); % Label for the y-axis
title('Water Column Displacement Over Time for All Tests'); % Title for the plot
grid on; % Add grid lines

% Add legend with test identifiers
legend({'Test 1: 10mm', 'Test 2: 15mm', 'Test 3: 20mm', 'Test 4: 25mm', ...
        'Test 5: 30mm', 'Test 6: 35mm', 'Test 7: 40mm'}, 'Location', 'best');

% Set x-axis limits if needed
xlim([10 20]); % Limit x-axis to [10, 20]

hold off; % Release the hold on the figure


% Plot RMS power against orifice diameter
figure(); % Create a new figure
plot(odia, PRMSVEC, 'r', 'LineWidth', 2); % Plot RMS power vs diameter
xlabel('Diameter (mm)'); % Label for the x-axis
ylabel('RMS Power (W)'); % Label for the y-axis
title('RMS Power vs Orifice Diameter'); % Title for the plot
grid on; % Add grid lines

% Plot RAO against orifice diameter
figure(); % Create a new figure
plot(odia, RAOVEC, 'r', 'LineWidth', 2); % Plot RAO vs diameter
xlabel('Diameter (mm)'); % Label for the x-axis
ylabel('RAO (m/m)'); % Label for the y-axis
title('Response Amplitude Operator (RAO) vs Orifice Diameter'); % Title for the plot
grid on; % Add grid lines
